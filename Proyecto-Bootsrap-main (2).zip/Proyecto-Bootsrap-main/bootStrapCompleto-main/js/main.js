let app = document.getElementById('typewriter');

let typewriter = new Typewriter(app, {
    loop: true,
    delay: 75,
});

typewriter
    .pauseFor(2500)
    .typeString('APM Terminals Algeciras')
    .pauseFor(200)
    .deleteChars(10)
    .start();

document.addEventListener("DOMContentLoaded", function () {
    const mapContainer = document.getElementById('map');

    // Verifica si el navegador soporta geolocalización
    if ("geolocation" in navigator) {
        // Obtiene la posición actual del usuario
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;

                // Crea un mapa usando Leaflet (una biblioteca de mapas)
                const map = L.map(mapContainer).setView([latitude, longitude], 15);

                // Añade un marcador en la ubicación actual
                L.marker([latitude, longitude]).addTo(map)
                    .bindPopup("Tu ubicación actual").openPopup();

                // Añade una capa de mapa base (puedes cambiar esto según tus preferencias)
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);
            },
            (error) => {
                console.error("Error obteniendo la ubicación:", error);
            }
        );


    }
});

let tareas = [];
let historialVisible = false;

document.addEventListener('DOMContentLoaded', function() {
    tareas = JSON.parse(localStorage.getItem('tareas')) || [];
    actualizarTareas();
});

function toggleFormulario() {
    const formulario = document.getElementById('formularioTarea');
    formulario.classList.toggle('oculto');
}

function crearTarea() {
    const nombre = document.getElementById('nombreTarea').value;
    const maquina = document.getElementById('maquinaTarea').value;
    const responsable = document.getElementById('responsable').value;
    const comentarios = document.getElementById('comentarios').value;

    // Retrieve the file input element and get the selected files
    const archivosInput = document.getElementById('archivos');
    const archivos = archivosInput.files;

    // Create an object with the tarea data, including the files
    const tarea = {
        nombre,
        maquina,
        responsable,
        comentarios,
        archivos: [],  // initialize as an empty array to avoid potential issues
        lista: false,
    };

    // If files are selected, add them to the tarea object
    if (archivos.length > 0) {
        for (let i = 0; i < archivos.length; i++) {
            tarea.archivos.push({
                name: archivos[i].name,
                // Add more file information if needed
            });
        }
    }

    tareas.push(tarea);

    localStorage.setItem('tareas', JSON.stringify(tareas));
    actualizarTareas();
    limpiarFormulario();
}


function actualizarTareas() {
    const tareasContainer = document.getElementById('tareasContainer');
    tareasContainer.innerHTML = '';

    tareas.forEach((tarea, index) => {
        const tarjeta = crearTarjeta(tarea, index, false);
        tareasContainer.appendChild(tarjeta);
    });

    actualizarHistorial();
}

function limpiarFormulario() {
    document.getElementById('formTarea').reset();
    toggleFormulario();
}

function confirmarTarea(index) {
    const confirmacion = confirm('¿La tarea está lista?');

    if (confirmacion) {
        const tareaCompletada = tareas[index];
        tareaCompletada.lista = true;

        const historialTareas = JSON.parse(localStorage.getItem('historialTareas')) || [];
        historialTareas.push(tareaCompletada);
        localStorage.setItem('historialTareas', JSON.stringify(historialTareas));

        const tareasPendientes = tareas.filter(tarea => !tarea.lista);
        tareas = [...tareasPendientes];
        localStorage.setItem('tareas', JSON.stringify(tareas));

        actualizarTareas();
    }
}

function actualizarHistorial() {
    const historialTareasContainer = document.getElementById('historialTareasContainer');
    historialTareasContainer.innerHTML = '';

    const historialTareas = JSON.parse(localStorage.getItem('historialTareas')) || [];

    if (historialVisible) {
        historialTareas.forEach(tarea => {
            // Set a green gradient background style for historial tarjetas
            const gradientStyle = 'background: linear-gradient(to right, #a1ffce, #faffd1);';

            const tarjetaHistorial = crearTarjeta(tarea, null, true);
            
            // Apply the gradient background style
            tarjetaHistorial.setAttribute('style', gradientStyle);

            historialTareasContainer.appendChild(tarjetaHistorial);
        });
    }
}


function crearTarjeta(tarea, index, esHistorial) {
    const tarjeta = document.createElement('div');
    tarjeta.classList.add('tarjetaTarea', 'mb-3', 'p-3', 'border', 'border-primary');

    if (esHistorial) {
        tarjeta.classList.add('tarjetaHistorial');
    }

    // Add a gradient background style for a subtle red gradient
    const gradientStyle = 'background: linear-gradient(to right, #ff9a9e, #fad0c4);';
    tarjeta.innerHTML = `
        <p><strong>Nombre:</strong> ${tarea.nombre}</p>
        <p><strong>Máquina:</strong> ${tarea.maquina}</p>
        <p><strong>Responsable:</strong> ${tarea.responsable}</p>
        <p><strong>Comentarios:</strong> ${tarea.comentarios}</p>
    `;

    // Check if the archivos property exists and has files
    if (tarea.archivos && tarea.archivos.length > 0) {
        tarjeta.innerHTML += '<p><strong>Archivos Adjuntos:</strong></p>';
        tarea.archivos.forEach(file => {
            tarjeta.innerHTML += `<p>${file.name}</p>`;
            // You can display additional file information as needed
        });
    }

    if (!esHistorial) {
        tarjeta.innerHTML += `
            <div class="checkboxContainer">
                <input type="checkbox" id="checkbox${index}" onchange="confirmarTarea(${index})">
                <label for="checkbox${index}">¿Tarea lista?</label>
            </div>
        `;
    }

    // Apply the gradient background style
    tarjeta.setAttribute('style', gradientStyle);

    return tarjeta;
}



document.getElementById('btnCrearTarea').addEventListener('click', toggleFormulario);

document.getElementById('btnHistorial').addEventListener('click', function () {
    historialVisible = !historialVisible;
    actualizarHistorial();
});